#include "MineSweeper.h"
int main(){ MineSweeper minesweeper = MineSweeper();  minesweeper.BeginS(); return 0;}